package book_service;

import java.util.List;
import javax.ws.rs.GET;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.POST;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;

@Path("/books")
public class BookService {
	List<Book> books;
	
	public BookService() {
		books = Books.getBooks();
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Book> getBooks() {
		return books;
	}
	
	@Path("{id}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Book getBook(@PathParam("id") int id) {
		  for(Book b : books) {
			  if ( b.getId() == id)
				   return b;
		  }
		  // book with the given id is not found, so throw 404 error
		  throw new NotFoundException(); 
	}
	
	@POST
	@Path("/create")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Book> addABook(@FormParam("title") String title, @FormParam("price") String price) {
		  Book book = new Book();
		  book.setTitle(title);
		  book.setPrice(Double.parseDouble(price));
		  Books.addBook(book);
		  return Books.getBooks();
	}
	
	@DELETE
	@Path("/delete/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Book> removeABook(@PathParam("id") int id) {
		  Books.removeBook(id);
		  return Books.getBooks();
	}
}